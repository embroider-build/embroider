export { default } from '<%= modulePath %>';
