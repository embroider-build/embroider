export { default } from '<%= routeModulePath %>';
