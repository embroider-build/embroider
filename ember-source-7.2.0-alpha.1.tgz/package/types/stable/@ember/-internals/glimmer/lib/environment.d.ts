declare module '@ember/-internals/glimmer/lib/environment' {
    import type { InternalOwner } from "@ember/-internals/owner";
    import type { EnvironmentDelegate } from "@glimmer/runtime/lib/environment";
    export class EmberEnvironmentDelegate implements EnvironmentDelegate {
        owner: InternalOwner;
        isInteractive: boolean;
        enableDebugTooling: boolean;
        constructor(owner: InternalOwner, isInteractive: boolean);
        onTransactionCommit(): void;
    }
}