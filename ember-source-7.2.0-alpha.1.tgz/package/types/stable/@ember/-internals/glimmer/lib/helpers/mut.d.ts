declare module '@ember/-internals/glimmer/lib/helpers/mut' {
    /**
      The `mut` helper is a shortcut for updating for args.
        
      However, defining update functions on your backing class is preferable to using `mut`.
        
      More directly: Don't use `mut`.

      The `mut` helper, when used with `fn`, will return a function that
      sets the value passed to `mut` to its first argument. As an example, we can create a
      button that increments a value passing the value directly to the `fn`:

      ```handlebars
      <MyChild @childClickCount={{this.totalClicks}} @clickCountChange={{fn (mut this.totalClicks)}} />
      ```

      The child `Component` would invoke the function with the new click count:

      ```app/components/my-child.gjs
      import Component from '@glimmer/component';
      import { action } from '@ember/object';
        
      export default class MyChild extends Component {
        @action
        update() {
          this.args.clickCountChange(this.args.childClickCount + 1);
        }
        
        <template>
          <button {{on "click" this.update}}>
            Click me!
          </button>
        </template>
      }
      ```

      The `mut` helper changes the `totalClicks` value to what was provided as the `fn` argument.

      @method mut
      @param {Object} [attr] the "two-way" attribute that can be modified.
      @for Ember.Templates.helpers
      @public
    */
    const _default: object;
    export default _default;
}