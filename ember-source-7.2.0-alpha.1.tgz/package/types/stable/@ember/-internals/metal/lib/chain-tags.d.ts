declare module '@ember/-internals/metal/lib/chain-tags' {
    import type { Meta } from "@ember/-internals/meta/lib/meta";
    import type { Tag } from "@glimmer/interfaces";
    import type { TagMeta } from "@glimmer/validator/lib/meta";
    export const CHAIN_PASS_THROUGH: WeakSet<WeakKey>;
    export function finishLazyChains(meta: Meta, key: string, value: any): void;
    export function getChainTagsForKeys(obj: object, keys: string[], tagMeta: TagMeta, meta: Meta | null): Tag;
    export function getChainTagsForKey(obj: object, key: string, tagMeta: TagMeta, meta: Meta | null): Tag;
}