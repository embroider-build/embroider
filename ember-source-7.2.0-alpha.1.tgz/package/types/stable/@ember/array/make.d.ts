declare module '@ember/array/make' {
    export { default } from "@ember/array/lib/make-array";
}