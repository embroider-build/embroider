declare module '@glimmer/compiler/lib/passes/1-normalization/keywords/call' {
    export const CALL_KEYWORDS: import("@glimmer/compiler/lib/passes/1-normalization/keywords/impl").Keywords<"Call", never>;
}