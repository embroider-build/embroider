declare module '@glimmer/compiler/lib/passes/1-normalization/keywords/utils/log' {
    import type * as ASTv2 from "@glimmer/syntax/lib/v2/api";
    import type { KeywordDelegate } from "@glimmer/compiler/lib/passes/1-normalization/keywords/impl";
    import * as mir from "@glimmer/compiler/lib/passes/2-encoding/mir";
    export const logKeyword: KeywordDelegate<ASTv2.CallExpression | ASTv2.AppendContent, ASTv2.PositionalArguments, mir.Log>;
}