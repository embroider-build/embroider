declare module '@glimmer/compiler/lib/passes/1-normalization/visitors/expressions' {
    import type { PresentArray } from "@glimmer/interfaces";
    import * as ASTv2 from "@glimmer/syntax/lib/v2/api";
    import type { AnyOptionalList, PresentList } from "@glimmer/compiler/lib/shared/list";
    import type { NormalizationState } from "@glimmer/compiler/lib/passes/1-normalization/context";
    import { Result } from "@glimmer/compiler/lib/shared/result";
    import * as mir from "@glimmer/compiler/lib/passes/2-encoding/mir";
    export class NormalizeExpressions {
        visit(node: ASTv2.ExpressionNode, state: NormalizationState): Result<mir.ExpressionNode>;
        visitList(nodes: PresentArray<ASTv2.ExpressionNode>, state: NormalizationState): Result<PresentList<mir.ExpressionNode>>;
        visitList(nodes: readonly ASTv2.ExpressionNode[], state: NormalizationState): Result<AnyOptionalList<mir.ExpressionNode>>;
        /**
         * Normalize paths into `hir.Path` or a `hir.Expr` that corresponds to the ref.
         *
         * TODO since keywords don't support tails anyway, distinguish PathExpression from
         * VariableReference in ASTv2.
         */
        PathExpression(path: ASTv2.PathExpression): Result<mir.ExpressionNode>;
        VariableReference(ref: ASTv2.VariableReference): ASTv2.VariableReference;
        Literal(literal: ASTv2.LiteralExpression): ASTv2.LiteralExpression;
        Keyword(keyword: ASTv2.KeywordExpression): ASTv2.KeywordExpression;
        Interpolate(expr: ASTv2.InterpolateExpression, state: NormalizationState): Result<mir.InterpolateExpression>;
        CallExpression(expr: ASTv2.CallExpression, state: NormalizationState): Result<mir.ExpressionNode>;
        Args({ positional, named, loc }: ASTv2.Args, state: NormalizationState): Result<mir.Args>;
        Positional(positional: ASTv2.PositionalArguments, state: NormalizationState): Result<mir.Positional>;
        NamedArguments(named: ASTv2.NamedArguments, state: NormalizationState): Result<mir.NamedArguments>;
    }
    export function convertPathToCallIfKeyword(path: ASTv2.ExpressionNode): ASTv2.ExpressionNode;
    export const VISIT_EXPRS: NormalizeExpressions;
}