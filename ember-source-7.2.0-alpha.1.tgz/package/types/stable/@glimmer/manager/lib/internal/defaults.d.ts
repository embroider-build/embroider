declare module '@glimmer/manager/lib/internal/defaults' {
    import type { CapturedArguments as Arguments, HelperCapabilities, HelperManagerWithValue } from "@glimmer/interfaces";
    type AnyFunction = (...args: any[]) => unknown;
    interface State {
        fn: AnyFunction;
        args: Arguments;
    }
    export class FunctionHelperManager implements HelperManagerWithValue<State> {
        capabilities: HelperCapabilities;
        createHelper(fn: AnyFunction, args: Arguments): State;
        getValue({ fn, args }: State): unknown;
        getDebugName(fn: AnyFunction): string;
    }
    export {};
}