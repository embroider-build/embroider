declare module '@glimmer/manager/lib/public' {
    export * from "@glimmer/manager/lib/public/api";
}