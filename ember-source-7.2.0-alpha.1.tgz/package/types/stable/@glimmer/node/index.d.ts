declare module '@glimmer/node' {
    export { default as NodeDOMTreeConstruction } from "@glimmer/node/lib/node-dom-helper";
    export { serializeBuilder } from "@glimmer/node/lib/serialize-builder";
}