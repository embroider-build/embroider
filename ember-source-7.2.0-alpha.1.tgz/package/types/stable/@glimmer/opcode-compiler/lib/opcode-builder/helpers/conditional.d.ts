declare module '@glimmer/opcode-compiler/lib/opcode-builder/helpers/conditional' {
    import type { PushStatementOp } from "@glimmer/opcode-compiler/lib/syntax/compilers";
    export type When = (match: number, callback: () => void) => void;
    export function SwitchCases(op: PushStatementOp, bootstrap: () => void, matcher: (when: When) => void): void;
    /**
     * A convenience for pushing some arguments on the stack and
     * running some code if the code needs to be re-executed during
     * updating execution if some of the arguments have changed.
     *
     * # Initial Execution
     *
     * The `args` function should push zero or more arguments onto
     * the stack and return the number of arguments pushed.
     *
     * The `body` function provides the instructions to execute both
     * during initial execution and during updating execution.
     *
     * Internally, this function starts by pushing a new frame, so
     * that the body can return and sets the return point ($ra) to
     * the ENDINITIAL label.
     *
     * It then executes the `args` function, which adds instructions
     * responsible for pushing the arguments for the block to the
     * stack. These arguments will be restored to the stack before
     * updating execution.
     *
     * Next, it adds the Enter opcode, which marks the current position
     * in the DOM, and remembers the current $pc (the next instruction)
     * as the first instruction to execute during updating execution.
     *
     * Next, it runs `body`, which adds the opcodes that should
     * execute both during initial execution and during updating execution.
     * If the `body` wishes to finish early, it should Jump to the
     * `FINALLY` label.
     *
     * Next, it adds the FINALLY label, followed by:
     *
     * - the Exit opcode, which finalizes the marked DOM started by the
     *   Enter opcode.
     * - the Return opcode, which returns to the current return point
     *   ($ra).
     *
     * Finally, it adds the ENDINITIAL label followed by the PopFrame
     * instruction, which restores $fp, $sp and $ra.
     *
     * # Updating Execution
     *
     * Updating execution for this `replayable` occurs if the `body` added an
     * assertion, via one of the `JumpIf`, `JumpUnless` or `AssertSame` opcodes.
     *
     * If, during updating executon, the assertion fails, the initial VM is
     * restored, and the stored arguments are pushed onto the stack. The DOM
     * between the starting and ending markers is cleared, and the VM's cursor
     * is set to the area just cleared.
     *
     * The return point ($ra) is set to -1, the exit instruction.
     *
     * Finally, the $pc is set to to the instruction saved off by the
     * Enter opcode during initial execution, and execution proceeds as
     * usual.
     *
     * The only difference is that when a `Return` instruction is
     * encountered, the program jumps to -1 rather than the END label,
     * and the PopFrame opcode is not needed.
     */
    export function Replayable(op: PushStatementOp, args: () => number, body: () => void): void;
    /**
     * A specialized version of the `replayable` convenience that allows the
     * caller to provide different code based upon whether the item at
     * the top of the stack is true or false.
     *
     * As in `replayable`, the `ifTrue` and `ifFalse` code can invoke `return`.
     *
     * During the initial execution, a `return` will continue execution
     * in the cleanup code, which finalizes the current DOM block and pops
     * the current frame.
     *
     * During the updating execution, a `return` will exit the updating
     * routine, as it can reuse the DOM block and is always only a single
     * frame deep.
     */
    export function ReplayableIf(
     op: PushStatementOp,
     args: () => number,
     ifTrue: () => void,
     ifFalse?: () => void
    ): void;
}