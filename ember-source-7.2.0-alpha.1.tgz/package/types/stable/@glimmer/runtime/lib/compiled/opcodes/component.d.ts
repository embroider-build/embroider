declare module '@glimmer/runtime/lib/compiled/opcodes/component' {
    import type { Bounds, CapabilityMask, CapturedArguments, ComponentDefinition, ComponentDefinitionState, ComponentInstanceState, ComponentInstanceWithCreate, Dict, DynamicScope, ElementOperations, InternalComponentManager, ModifierInstance, Nullable, ProgramSymbolTable, ScopeSlot, UpdatingOpcode, WithUpdateHook } from "@glimmer/interfaces";
    import type { Reference } from "@glimmer/reference/lib/reference";
    import type { UpdatingVM } from "@glimmer/runtime/lib/vm";
    import type { VM } from "@glimmer/runtime/lib/vm/append";
    /**
     * The VM creates a new ComponentInstance data structure for every component
     * invocation it encounters.
     *
     * Similar to how a ComponentDefinition contains state about all components of a
     * particular type, a ComponentInstance contains state specific to a particular
     * instance of a component type. It also contains a pointer back to its
     * component type's ComponentDefinition.
     */
    export interface InitialComponentInstance {
        definition: ComponentDefinition;
        manager: Nullable<InternalComponentManager>;
        capabilities: Nullable<CapabilityMask>;
        state: null;
        handle: Nullable<number>;
        table: Nullable<ProgramSymbolTable>;
        lookup: Nullable<Dict<ScopeSlot>>;
    }
    export interface PopulatedComponentInstance {
        definition: ComponentDefinition;
        manager: InternalComponentManager;
        capabilities: CapabilityMask;
        state: null;
        handle: number;
        table: Nullable<ProgramSymbolTable>;
        lookup: Nullable<Dict<ScopeSlot>>;
    }
    export interface PartialComponentDefinition {
        state: Nullable<ComponentDefinitionState>;
        manager: InternalComponentManager;
    }
    export class ComponentElementOperations implements ElementOperations {
        private attributes;
        private classes;
        private modifiers;
        setAttribute(name: string, value: Reference, trusting: boolean, namespace: Nullable<string>): void;
        setStaticAttribute(name: string, value: string, namespace: Nullable<string>): void;
        addModifier(vm: VM, modifier: ModifierInstance, capturedArgs: CapturedArguments): void;
        flush(vm: VM): ModifierInstance[];
    }
    export class UpdateComponentOpcode implements UpdatingOpcode {
        private component;
        private manager;
        private dynamicScope;
        constructor(component: ComponentInstanceState, manager: WithUpdateHook, dynamicScope: Nullable<DynamicScope>);
        evaluate(_vm: UpdatingVM): void;
    }
    export class DidUpdateLayoutOpcode implements UpdatingOpcode {
        private component;
        private bounds;
        constructor(component: ComponentInstanceWithCreate, bounds: Bounds);
        evaluate(vm: UpdatingVM): void;
    }
}