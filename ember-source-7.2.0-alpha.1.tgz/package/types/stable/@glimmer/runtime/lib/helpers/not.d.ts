declare module '@glimmer/runtime/lib/helpers/not' {
    export const not: (...args: unknown[]) => boolean;
}