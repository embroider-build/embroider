declare module '@glimmer/syntax/lib/v2/api' {
    export * from "@glimmer/syntax/lib/v2/objects/args";
    export * from "@glimmer/syntax/lib/v2/objects/attr-block";
    export type * from "@glimmer/syntax/lib/v2/objects/base";
    export * from "@glimmer/syntax/lib/v2/objects/content";
    export * from "@glimmer/syntax/lib/v2/objects/expr";
    export * from "@glimmer/syntax/lib/v2/objects/internal-node";
    export * from "@glimmer/syntax/lib/v2/objects/node";
    export * from "@glimmer/syntax/lib/v2/objects/refs";
    export * from "@glimmer/syntax/lib/v2/objects/resolution";
}