declare module '@glimmer/util' {
    import { LOCAL_LOGGER, LOGGER } from "@glimmer/util/lib/local-logger";
    export * from "@glimmer/util/lib/array-utils";
    export { dict, isDict, isIndexable, StackImpl as Stack } from "@glimmer/util/lib/collections";
    export { beginTestSteps, endTestSteps, logStep, verifySteps } from "@glimmer/util/lib/debug-steps";
    export * from "@glimmer/util/lib/dom";
    export { default as intern } from "@glimmer/util/lib/intern";
    export { isSerializationFirstNode, SERIALIZATION_FIRST_NODE_STRING, } from "@glimmer/util/lib/is-serialization-first-node";
    export { assign, entries, keys, values } from "@glimmer/util/lib/object-utils";
    export * from "@glimmer/util/lib/string";
    export type FIXME<T, S extends string> = (T & S) | T;
    export { LOCAL_LOGGER, LOGGER };
    export function assertNever(value: never, desc?: string): never;
}