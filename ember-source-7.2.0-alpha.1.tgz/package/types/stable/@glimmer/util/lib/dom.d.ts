declare module '@glimmer/util/lib/dom' {
    import type { SimpleElement } from "@glimmer/interfaces";
    export function clearElement(parent: SimpleElement): void;
}