declare module '@glimmer/util/lib/object-utils' {
    export const assign: {
        <T extends {}, U>(target: T, source: U): T & U;
        <T extends {}, U, V>(target: T, source1: U, source2: V): T & U & V;
        <T extends {}, U, V, W>(target: T, source1: U, source2: V, source3: W): T & U & V & W;
        (target: object, ...sources: any[]): any;
    };
    export function values<T>(
        obj: {
            [s: string]: T;
        }
    ): T[];
    export type ObjectEntry<D extends object> = {
        [P in keyof D]: [P, D[P]];
    }[keyof D];
    export function entries<D extends object>(dict: D): ObjectEntry<D>[];
    export function keys<T extends object>(obj: T): (keyof T)[];
}