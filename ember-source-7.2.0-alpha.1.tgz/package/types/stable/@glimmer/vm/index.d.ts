declare module '@glimmer/vm' {
    export { ContentType } from "@glimmer/vm/lib/content";
    export { ARG_SHIFT, InternalComponentCapabilities, 
    /** @deprecated */
    InternalComponentCapabilities as InternalComponentCapability, MACHINE_MASK, MAX_SIZE, OPERAND_LEN_MASK, TYPE_MASK, TYPE_SIZE, } from "@glimmer/vm/lib/flags";
    export type { MachineRegister, Register, SyscallRegister } from "@glimmer/vm/lib/registers";
    export type { SavedRegister, TemporaryRegister } from "@glimmer/vm/lib/registers";
    export { $fp, $pc, $ra, $s0, $s1, $sp, $t0, $t1, $v0, isLowLevelRegister } from "@glimmer/vm/lib/registers";
}