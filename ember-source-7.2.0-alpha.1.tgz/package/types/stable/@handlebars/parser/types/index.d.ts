declare module '@handlebars/parser/types' {
    import * as AST from "@handlebars/parser/types/ast";

    export { AST };

    export interface ParseOptions {
      srcName?: string;
      ignoreStandalone?: boolean;
    }

    export function parse(input: string, options?: ParseOptions): AST.Program;
    export function parseWithoutProcessing(input: string, options?: ParseOptions): AST.Program;
}