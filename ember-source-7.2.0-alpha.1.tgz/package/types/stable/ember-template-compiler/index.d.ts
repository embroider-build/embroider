declare module 'ember-template-compiler' {
    export * from "ember-template-compiler/lib/public-api";
}