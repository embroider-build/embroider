declare module 'ember-testing/lib/test/pending_requests' {
    export function pendingRequests(): number;
}